<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Traffic Light Controller</title>
    <style>
        body {
            background-image: url('https://t3.ftcdn.net/jpg/11/02/65/06/360_F_1102650642_gW5FBabfoWsuyJNsKhPVOssFQ1MEDVUq.webp');
            background-size: cover;
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
        }
        .light {
            width: 120px;
            height: 300px;
            border: 11px solid #000;
            border-radius: 25px;
            margin: 30px auto;
            position: relative;
            
        }
        .light div {
            width:96%;
            height: 30%;
            border: 2px solid #000;
            border-radius: 30%;
            margin: 5px 0;
            opacity: 0.2;
        }
        .red { background: red; }
        .yellow { background: yellow; }
        .green { background: green; }
        #status {
            font-size: 2em;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Traffic Light Controller</h1>
    <div class="light">
        <div class="red" id="redLight"></div>
        <div class="yellow" id="yellowLight"></div>
        <div class="green" id="greenLight"></div>
    </div>
    <div id="status">Current State: Red</div>
    <script>
        let currentState = 0; // 0: Red, 1: Green, 2: Yellow
        const lights = [
            document.getElementById('redLight'), 
            document.getElementById('yellowLight'), 
            document.getElementById('greenLight')
        ];
        const status = document.getElementById('status');

        function changeLight() {
            lights.forEach(light => light.style.opacity = 0.3); // Set all lights to dim
            lights[currentState].style.opacity = 1; // Brighten the current light

            // Update status based on current state before it changes
            if (currentState === 0) {
                status.innerText = "Current State: Red";
                currentState = 1; 
            } else if (currentState === 1) {
                status.innerText = "Current State: Yellow";
                currentState = 2; 
            } else {
                status.innerText = "Current State: Green";
                currentState = 0; 
            }
        }

        setInterval(changeLight, 5000); // Change lights every 5 seconds
    </script>
    
    <footer>
        <p>© HassanZaman, <?php echo date("Y-m-d"); ?></p>
    </footer>
</body>
</html>